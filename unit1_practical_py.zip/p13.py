#filter

lst = [11,25,2,45,3,39]

filtered_result = filter (lambda x: x >= 4, lst)

print(list(filtered_result))

#map

filtered_result = map (lambda x: x*x, lst)

print(list(filtered_result))

#reduce

from functools import reduce

sequences = [1,2,3,4,5]

product = reduce (lambda x, y: x*y, sequences)

print(product)