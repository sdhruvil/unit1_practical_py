
lst=[4,9,7]

for i in range(3):
    print(lst[i]*"*")