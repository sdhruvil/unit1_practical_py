
#list using menu


lst=[1,2,3,4,5,6]

while True:
    print("1 Append in a list")
    print("2 inser in a list")
    print("3 count ")
    print("4 length of list")
    choice=input("Enter Your choice:")
    
    
    

    if choice=="1":
        lst.append(98)
        print (lst)

    elif choice=="2":
        lst.insert(0,145)
        print (lst)

    elif choice=="3":
        b=lst.count()
        print (b)

    elif choice=="4":
        # lst.clear()
        print(len(lst))
        

    else:
        print("Enter valid choice")

