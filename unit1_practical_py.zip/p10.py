
no1=int(input("Enter Number1:"))
no2=int(input("Enter Number2:"))

add=lambda no1,no2:no1+no2
result=add(no1,no2)
print("Addition is",result)

sub=lambda no1,no2:no1-no2
result=sub(no1,no2)
print("Subtraction is",result)

mul=lambda no1,no2:no1*no2
result=mul(no1,no2)
print("Multiplication is",result)

div=lambda no1,no2:no1/no2
result=div(no1,no2)
print("Division is",result)
