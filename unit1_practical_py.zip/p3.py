#enter marks and perform total,percentage,garade

py=int(input("Enter marks of Python subject: "))
dav=int(input("Enter marks of DAV subject: "))
android=int(input("Enter marks of Android subject: "))
cn=int(input("Enter marks of Cn subject: "))

total=py+dav+android+cn
print("Total marks of above mention subject: ",total)

per=total/4
print("percentage is: ",per)

if per>=95:
    print("Excellent")

elif (per<=95 and per>=80):
    print("very good")


elif (per<=79 and per>=60):
    print("good")


elif (per<=59 and per>=40):
    print("do hard work")
    
else:
    print("fail")
