#odd number 

lst=[]
lst1=[]

for j in range(10):
    no=int(input("Enter a number:"))
    lst.append(no)
    

for i in lst:
     if i%2!=0:
         lst1.append(i)


print("Odd number is:",lst1)
print("Maximum Odd number is :",max(lst1))


