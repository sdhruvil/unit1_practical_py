
first=int(input("Enter First value:"))
second=int(input("Enter Second value:"))
s=input("Enter Sign:")

def arithmatic(x,y,sign):

    if sign=="+":
        return x+y
    
    elif sign=="-":
        return x-y
    
    elif sign=="*":
        return x*y
    
    else:
        return x/y
    
res=arithmatic(first,second,s)

print("Result of given Number is:",res)



