
def myFun(*argv):
    for arg in argv:
        print(arg)
 
 
myFun(1,2,3,4)