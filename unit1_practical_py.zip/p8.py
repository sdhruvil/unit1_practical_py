


#1count vowels

# Count = input("Enter a String:")

# count = 0

# vowels = ["a", "e", "i", "o", "u","A", "E", "I", "O", "U"]

# for i in range(len(Count)):
#     if Count[i] in vowels:
#         count += 1

# print("Number of vowels in the given string is: ", count)
#----------------------------------------------------------------

#2count length of string

str=input("Enter a String:")

count = 0

for t in str:

    count+=1 

print("Total length of String is: ",count) 

#----------------------------------------------------------------

#3reverse string
# revtxt = str[::-1]
# print(revtxt)


#4 find and replace 

# replace=input("Enter string you want to replace?:")

# new_string = str.replace(replace, "Good Bye")
 
# print(new_string)


#5string is palindrom or not

revtxt = str[::-1]

if str==revtxt:
    print("String is palindrom")

else:
    print("String is not palindrom")
    

