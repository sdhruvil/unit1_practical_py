l1=[]
f_result=[]

for i in range(10):
    l1.append(int(input("Enter Number: ")))
    
for i in range(10):
    number=l1[i]
    temp=number
    res=0
    length=len(str(number))
    
    while number>0:
        rem=number%10
        res+=rem**length
        number=number//10
        
    if temp==res:
        f_result.append(temp)
        
print("Armstrong number are: ",end=' ')
for i in f_result:
    print(i,end=' ')
          
