
#find out simple interest

p=float(input("Enter principal Amount: "))
r=float(input("Enter Rate of interest: "))
n=float(input("Enter Number of year: "))

i=p*r*n/100

print("Simple interest is: ",i)
