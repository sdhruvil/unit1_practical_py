#Arithmatic operation

no1=float(input("Enter Value1: "))

no2=float(input("Enter Value2: "))
choice=input("Enter a valid sign as per operation +,-,*,/,%")

if choice=="+":
    print("Adition of ",no1,"and ",no2,"is",no1+no2)

elif choice=="-":
    print("subtraction of ",no1,"and ",no2,"is",no1-no2)

elif choice=="*":
    print("multiplication of ",no1,"and ",no2,"is",no1*no2)

elif choice=="/":
    print("division of ",no1,"and ",no2,"is",no1/no2)

elif choice=="%":
    print("Modulo of ",no1,"and ",no2,"is",no1%no2)

else:
    print("Enter valid choice")
