a=5  #global

def disp():
    b=10 #local
    print(b)
   
    def show():
        nonlocal c=15 #nonlocal
        print(c)

    show()

disp()

print(a)
        
